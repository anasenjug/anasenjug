import numpy as np
import matplotlib.pyplot as plt

img=plt.imread("C:\\Users\\student\\Desktop\\lv2_psu\\treci\\tiger.png")
img=img[:,:,0].copy()

print(img.shape)
(h,w)=img.shape

print(img)
img_br=img.copy()

for i in range (0,h):
    for j in range (0,w):
        if img_br[i,j]+0.1<=1:
            img_br[i,j]=img_br[i,j]+0.1


img_rot=np.zeros((w,h))

for i in range (0,h):
    img_rot[:,h-1-i]=img[i,:]

img_mirror=img_rot.transpose()

x=10

img_low=img[::x,::x]
img_cut=np.zeros((h,w))

img_cut[:,240:480] = img[:,240:480]

plt.imshow(img_cut, cmap='gray')
plt.show()
