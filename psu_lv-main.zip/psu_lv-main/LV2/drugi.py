import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

data = np.loadtxt(open("E:/OneDrive - etfos.hr/Desktop/materijali/2.god/PSU/LV/LV2/mtcars.csv", "rb"), usecols=(1,2,3,4,5,6),
delimiter=",", skiprows=1)

plt.scatter(data[:,4],data[:,1])
plt.xlabel('hp')
plt.ylabel('mpg')
plt.axis() 
plt.show()
