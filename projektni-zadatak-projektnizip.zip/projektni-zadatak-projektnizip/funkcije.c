#define _CRT_SECURE_NO_WARNINGS
#include "header.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

static int brojZapisa = 0;
static int brojKorisnika = 0;

void unos_imena_prezimena(FILE* fp, char **pok) {

	char pomocnoPolje[50] = { 0 };
	int duljina = 0;

	if (fp == NULL) {
		printf("Datoteka se ne moze otvoriti");
	}
	else {
		fscanf(fp, "%49[^\n]", pomocnoPolje);
		duljina = strlen(pomocnoPolje);
		*pok = (char*)calloc(duljina + 1, sizeof(char));
		if (*pok == NULL) {
			return;

		}

	}

	strcpy(*pok, pomocnoPolje);

}

void kreiranjeDatoteke(const char* const imeDatoteke) {
	FILE* fp = fopen(imeDatoteke, "wb");

	if (fp == NULL) {
		perror("Kreiranje datoteke");
		exit(EXIT_FAILURE);
	}
	fwrite(&brojKorisnika, sizeof(int), 1, fp);



	fclose(fp);
}

void noviZapis(const char* const imeDatoteke) {
	FILE* fp = fopen(imeDatoteke, "rb+");
	if (fp == NULL) {
		perror("Dodavanje zapisa..");
		exit(EXIT_FAILURE);
	}
	
	fread(&brojZapisa, sizeof(int), 1, fp);

	

}

void bmiKalkulator() {

	float bmi, tezina, visina;
	bmi = tezina / pow(visina, 2);

	printf("Vas BMI je: %f",bmi);

}