#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "header.h"

int izbornik(const char* const imeDatoteke) {
	printf("====================");
	printf("IZBORNIK");
	printf("====================\n");
	printf("\t\t\tOpcija 1: Novi korisnik\n");
	printf("\t\t\tOpcija 2: Novi zapis\n");
	printf("\t\t\tOpcija 3 :BMI kalkulator\n");
	printf("======================================\
======================================\n");
	int uvijet = 0;
	ZAPIS* poljeZapisa = NULL;
	

	scanf("%d", &uvijet);

	switch (uvijet) {
	case 1:
		kreiranjeDatoteke(imeDatoteke);
		break;
	
	case 2:
		noviZapis(imeDatoteke);
		break;
	case 3:

		bmiKalkulator();

	default:
		uvijet = 0;
	}
	
	return uvijet;
}